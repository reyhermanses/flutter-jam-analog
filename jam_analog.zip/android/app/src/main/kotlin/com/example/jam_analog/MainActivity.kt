package com.example.jam_analog

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
